package co.edu.unbosque.controller;
import co.edu.unbosque.view.MainFrame;

public class Controller {
	
	public static int GRID = 6;
	public static int GRID_TOTAL = GRID*GRID;
	
	private static MainFrame vnt;
	
	public Controller(){
		vnt = new MainFrame();
	}
	
	public void run() {
		vnt.setVisible(true);
	}

}
