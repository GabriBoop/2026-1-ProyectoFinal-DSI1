package co.edu.unbosque.model;
import co.edu.unbosque.controller.Controller;

public class Player {
	
	static int[] pos = new int[Controller.GRID_TOTAL];
	public Player(){
		
	}

}
