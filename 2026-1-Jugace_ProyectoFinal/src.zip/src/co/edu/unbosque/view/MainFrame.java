package co.edu.unbosque.view;
import co.edu.unbosque.controller.Controller;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.*;

public class MainFrame extends JFrame{ 
	
	private static final int ANCHO = 800;
	private static final int ALTO = 600;
	private static JPanel[] paneles = new JPanel[Controller.GRID_TOTAL];
	
	public MainFrame() {
	
		setBounds(0, 0, ANCHO, ALTO);
		setTitle("--GAME--");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(Controller.GRID, Controller.GRID));
		setLocationRelativeTo(null);
		
		insertPanel_PRUEBA();	
	}
	
	public void insertPanel_PRUEBA() {
		for(int i = 0; i < Controller.GRID_TOTAL; i++) {
			paneles[i] = new JPanel();
			
			paneles[i].setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			
			add(paneles[i]);
		}
		
	}
	
		
}

